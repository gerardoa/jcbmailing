<?php

function com_install ()
{
	mosRedirect("index2.php?option=com_cbmailing","CbMailing Successfully Installed");
}


?>
                                          