<?php

function com_uninstall () 
{
		echo "CbMailing Successfully Uninstalled";

}


?>                                                                                                                                                                                                                                                  